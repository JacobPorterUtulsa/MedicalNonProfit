<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Examples extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper('url');
		$this->load->model('login_model');
		$this->load->library('grocery_CRUD');
	}

	public function _example_output($output = null)
	{
		$this->load->view('Examples.php',(array)$output);
	}

	public function index()
	{
		$this->_example_output((object)array('output' => '' , 'js_files' => array() , 'css_files' => array()));
	}

	public function patients_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }

		try{
			$crud = new grocery_CRUD();
			//$crud = $this->login_model->check($crud);
			$crud->set_table('patients');
			$crud->set_subject('Patients');

			$crud->set_rules('patient_id','Patient ID','htmlspecialchars|max_length[15]');
			$crud->set_rules('last_name','Last Name','htmlspecialchars|required|min_length[2]|max_length[50]');
			$crud->set_rules('first_name','First Name','htmlspecialchars|required|min_length[2]|max_length[50]');
			$crud->set_rules('gender','Gender','htmlspecialchars|required|min_length[1]|max_length[7]');
			$crud->set_rules('diabetes','Confirmed Diabetic?','htmlspecialchars|required|min_length[1]|max_length[50]');
			$crud->set_rules('genetics','Genetics','htmlspecialchars|min_length[0]|max_length[5000]');
			$crud->set_rules('other_conditions','Other Conditions','htmlspecialchars|min_length[0]|max_length[5000]');

			$crud->field_type('gender','dropdown',array('1' => 'Male', '2' => 'Female','3' => 'Other'));
			$crud->field_type('diabetes','dropdown',array('1' => 'yes', '2' => 'no'));

			$crud->display_as('dob','Date of Birth');
			$crud->display_as('diabetes','Confirmed Diabetic?');
			$crud->display_as('first_name','First Name');
			$crud->display_as('last_name','Last Name');
			$crud->display_as('other_conditions','Other Conditions');

			$crud->fields('last_name','first_name','gender','dob','diabetes','genetics','other_conditions');
			$crud->required_fields('last_name','first_name','gender','dob','diabetes');
			$crud->columns('last_name','first_name','gender','dob','diabetes','genetics','other_conditions');
			//$crud = $this->login_model->check($crud);
			$output = $crud->render();

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}
	
	public function prescriptions_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }

		try{
			$crud = new grocery_CRUD();
			$crud->set_table('prescriptions');
			$crud->set_subject('Prescriptions');
			$crud->set_relation('prescription_patient_id','patients', '{first_name} {last_name}');
			$crud->set_relation('pmed_id','medications', 'med_name');

			$crud->set_rules('prescription_id','Prescription ID','htmlspecialchars|max_length[15]');
			$crud->set_rules('prescription_patient_id','Patient Name','htmlspecialchars|required|max_length[15]');
			$crud->set_rules('pmed_id','Name of Medication','htmlspecialchars|required|max_length[15]');
			$crud->set_rules('amount_per_day','Amount per Dosage','htmlspecialchars|required|min_length[1]|max_length[100]');
			$crud->set_rules('num_times_per_day','Number of Dosages a Day','htmlspecialchars|required|min_length[1]|max_length[100]');
			$crud->set_rules('other_info','Other Information','htmlspecialchars|min_length[0]|max_length[5000]');

			$crud->display_as('prescription_patient_id','Patient Name');
			$crud->display_as('num_times_per_day','Number of Dosages a Day');
			$crud->display_as('amount_per_day','Amount per Dosage');
			$crud->display_as('other_info','Other Information');
			$crud->display_as('date','Date Prescribed');
			$crud->display_as('pmed_id','Name of Medication');

			$crud->order_by('date','desc');

			$crud->field_type('num_times_per_day','dropdown',array('1' => '1 dosage', '2' => '2 dosages','3' => '3 dosages' , '4' => '4 dosages' , '5' => '5 dosages' , '6' => '6 dosages' ,  '7' => 'Wear all day'));
			$crud->field_type('amount_per_day','dropdown',array('1' => '1 unit', '2' => '2 units','3' => '3 units' , '4' => '4 units' , '5' => '5 units' , '6' => '6 units' ,  '7' => 'Wear all day'));
			$crud->field_type('prescription_id', 'hidden');

			$crud->fields('prescription_patient_id','date','pmed_id','amount_per_day','num_times_per_day','other_info');
			$crud->required_fields('prescription_patient_id','date','pmed_id','amount_per_day','num_times_per_day');
			$crud->unset_columns('prescription_id');
			$crud->columns('prescription_patient_id','date','pmed_id','amount_per_day','num_times_per_day','other_info');
			$crud = $this->login_model->check($crud);
			$output = $crud->render();
			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}


	public function visits_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }
		try{
			$crud = new grocery_CRUD();
			$crud->set_table('visits');
			$crud->set_subject('Visits');

			$crud->set_rules('visit_id','Visit ID','htmlspecialchars|max_length[15]');
			$crud->set_rules('dr_patient_id','Patient Name','htmlspecialchars|required|max_length[15]');
			$crud->set_rules('doctor_seen','Attending Doctor','htmlspecialchars|required|min_length[1]|max_length[200]');
			$crud->set_rules('FEV_value_max','FEV_value_max','htmlspecialchars|min_length[0]|max_length[10]');
			$crud->set_rules('FEV_value1','1st FEV value','htmlspecialchars|required|min_length[0]|max_length[10]');
			$crud->set_rules('FEV_value2','2nd FEV value','htmlspecialchars|min_length[0]|max_length[10]');
			$crud->set_rules('FEV_value3','3rd FEV value','htmlspecialchars|min_length[0]|max_length[10]');

			$crud->display_as('dr_patient_id','Patient Name');
			$crud->display_as('visit_date','Visit Time');
			$crud->display_as('doctor_seen','Attending Doctor');
			$crud->display_as('FEV_value_max','Maximum FEV Value');
			$crud->display_as('FEV_value1','1st FEV value');
			$crud->display_as('FEV_value2','2nd FEV value');
			$crud->display_as('FEV_value3','3rd FEV value');

			$crud->set_relation('dr_patient_id','patients', '{first_name} {last_name}');
			
			$crud->field_type('visit_date', 'date');
			$crud->field_type('visit_id', 'hidden');
			$crud->field_type('FEV_value_max', 'hidden');
			$crud->field_type('doctor_seen','dropdown',array('1' => 'Dr. Simpson', '2' => 'Dr. Wilson','3' => 'Dr. House' , '4' => 'Dr. Cox' , '5' => 'Dr. Seuss'));

			$crud->order_by('visit_date','desc');

			$crud->fields('visit_date', 'dr_patient_id', 'doctor_seen' , 'FEV_value_max','FEV_value1','FEV_value2','FEV_value3');
			$crud->required_fields('visit_date','dr_patient_id','doctor_seen','FEV_value1');
			$crud->columns('visit_date','dr_patient_id','doctor_seen','FEV_value_max');

			$crud->callback_before_insert(array($this,'set_max'));
			$crud->callback_before_update(array($this,'set_max'));
			$crud = $this->login_model->check($crud);
			$output = $crud->render();

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	function set_max($post_array) {
				$post_array['FEV_value_max'] = max($_POST['FEV_value1'],$_POST['FEV_value2'],$_POST['FEV_value3']);
			    return $post_array;
	    }//function

}
