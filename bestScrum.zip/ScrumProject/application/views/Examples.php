<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php 
foreach($css_files as $file): ?>
	<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
</head>
<body>

<div class="navbar">
  <div class="dropdown">
    <button class="dropbtn">
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href='<?php echo site_url('Examples/patients_management')?>'>Patients</a>
      <a href='<?php echo site_url('Examples/prescriptions_management')?>'>Prescriptions</a>
      <a href='<?php echo site_url('Examples/visits_management')?>'>Visits</a>
	  <a href='<?php echo site_url('login/logout')?>'>Logout</a>
    </div>
  </div>
</div>


	<div style='height:20px;'></div>  
    <div style="padding: 10px">
		<?php echo $output; ?>
    </div>
    <?php foreach($js_files as $file): ?>
        <script src="<?php echo $file; ?>"></script>
    <?php endforeach; ?>
</body>
</html>
