<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ExamplesAdmins extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper('url');
		$this->load->model('login_model');
		$this->load->library('grocery_CRUD');
	}

	public function _example_output($output = null)
	{
		$this->load->view('ExamplesAdmins.php',(array)$output);
	}

	public function index()
	{
		$this->_example_output((object)array('output' => '' , 'js_files' => array() , 'css_files' => array()));
	}

	public function users()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }

		try{
			$crud = new grocery_CRUD();
			$crud->set_table('crud_users');
			$crud->set_subject('Users');
			$crud->required_fields('username','password','permissions');
			$crud->set_rules('username','Username','htmlspecialchars|required|min_length[2]|max_length[30]');
			$crud->set_rules('password','Password','htmlspecialchars|required|min_length[12]|max_length[50]');
			$crud->set_rules('permissions','Permissions','htmlspecialchars|required|min_length[0]|max_length[5]');
			$crud->columns('username','password','permissions');
			$crud->field_type('password','password');
			$crud->unset_read()->unset_export()->unset_print();
			$crud->callback_before_insert(array($this,'encrypt_pw'));
			$crud->callback_before_update(array($this,'encrypt_pw'));
			$output = $crud->render();
			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}
	function encrypt_pw($post_array) {
		if(!empty($post_array['password'])) {
			$post_array['password'] = SHA1($_POST['password']);
			}
			return $post_array;
		}

}
