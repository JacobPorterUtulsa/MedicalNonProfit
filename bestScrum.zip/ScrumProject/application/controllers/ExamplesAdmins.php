<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ExamplesAdmins extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper('url');
		$this->load->model('login_model');
		$this->load->library('grocery_CRUD');
	}

	public function _example_output($output = null)
	{
		$this->load->view('ExamplesAdmins.php',(array)$output);
	}

	public function index()
	{
		$this->_example_output((object)array('output' => '' , 'js_files' => array() , 'css_files' => array()));
	}

	public function patients_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }

		try{
			$crud = new grocery_CRUD();
			$crud->set_table('patients');
			$crud->set_subject('patients');
			$crud->columns('first_name','last_name','gender','dob','genetics','diabetes','other_conditions');
			$output = $crud->render();

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}
	
	
	public function medications_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }

		try{
			$crud = new grocery_CRUD();
			$crud->set_table('medications');
			$crud->set_subject('medications');
			$crud->set_relation_n_n('med_dosag1','medication_management_dosages', 'med_dosages', 'med_id', 'med_dosage_id', 'num_times_per_day','priority');
			$crud->set_relation_n_n('med_dosag2','medication_management_dosages', 'med_dosages', 'med_id', 'med_dosage_id',  'amount_per_day','priority');
			$crud->display_as('med_dosag1','Number Of Times a Day');
			$crud->display_as('med_dosag2','Amount Per Day');
			$crud->columns('med_id','med_name','med_dosag1','med_dosag2');
			$output = $crud->render();
			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function visits_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }
		try{
			$crud = new grocery_CRUD();
			$crud->set_table('visits');
			$crud->set_subject('Patient Visit');
			//$crud->set_relation('FEV_id', 'lung_exams', '{lung_exam_id}');

			$crud->set_rules('visit_id','Visit Number','htmlspecialchars|required|max_length[15]');
			$crud->display_as('visit_id','Visit Number');
			
			$crud->set_rules('dr_patient_id','Patient Name','htmlspecialchars|required|max_length[15]');
			$crud->display_as('dr_patient_id','Patient Name');
			$crud->set_relation('dr_patient_id','patients', '{first_name} {last_name}');

			//$crud->set_relation_n_n('FEV_score', 'lung_visits', 'lung_exams', 'lung_visit_id', 'lung_exam_id', 'FEV_value');
			

			$crud->field_type('visit_date', 'date');
			$crud->field_type('FEV_value_max', 'hidden');
			$crud->display_as('visit_date','Visit Time');
			$crud->order_by('visit_date','desc');
			$crud->fields('visit_date', 'dr_patient_id', 'doctor_seen' , 'FEV_value_max','FEV_value1','FEV_value2','FEV_value3');
			$crud->columns('visit_date','dr_patient_id','doctor_seen','FEV_value_max');
			
			$crud->unset_delete();
			$crud->unset_clone();
			$crud->callback_before_insert(array($this,'set_max'));
			$crud->callback_before_update(array($this,'set_max'));

			
			$output = $crud->render();
			$output-> title = "Visits";

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

		public function lungvisit_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }
		try{
			$crud = new grocery_CRUD();
			$crud->set_table('lung_visits');
			$crud->set_subject('Lung Visit');
			
			$crud->set_rules('lung_exam_id','Visit Number','htmlspecialchars|required|max_length[15]');
			$crud->display_as('lung_exam_id','Score ID');
			$crud->display_as('FEV_value','FEV');
			
			$crud->columns('lung_exam_id','FEV_value');
			$crud->unset_clone();
			$output = $crud->render();
			$output-> title = "Lung Exams";

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function patient_medication_old_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }

		try{
			$crud = new grocery_CRUD();
			$crud->set_table('patient_medications_old');
			$crud->set_subject('patient_medications_old');
			$crud->set_relation('medications_patient_id','patients', '{first_name} {last_name}');
			$crud->display_as('medications_patient_id','Patient Name');
			$crud->unset_columns('medication_id');
			$crud->columns();
			$output = $crud->render();
			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function prescriptions_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }

		try{
			$crud = new grocery_CRUD();
			$crud->set_table('prescriptions');
			$crud->set_subject('prescriptions');
			$crud->set_rules('prescription_patient_id','Patient Name','htmlspecialchars|required|max_length[15]');
			$crud->display_as('prescription_patient_id','Patient Name');
			$crud->set_relation('prescription_patient_id','patients', '{first_name} {last_name}');
			
			$crud->set_relation_n_n('prescription_meds1', 'prescription_dosages', 'med_dosages', 'prescription_id', 'med_dosage_id', 'num_times_per_day');
			$crud->set_relation_n_n('prescription_meds2', 'prescription_dosages', 'med_dosages', 'prescription_id', 'med_dosage_id', 'amount_per_day');

			$crud->set_relation('pmed_id','medications', 'med_name');
			$crud->display_as('prescription_meds1','Number of Times a Day');
			$crud->display_as('prescription_meds2','Amount per Day');
			$crud->order_by('date','desc');
			$crud->display_as('pmed_id','Patient Name');
			$crud->unset_columns('prescription_id');
			$crud->columns('prescription_patient_id','date','prescription_meds1','prescription_meds2','pmed_id');
			$output = $crud->render();
			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	
	public function med_dosage_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }

		try{
			$crud = new grocery_CRUD();
			$crud->set_table('med_dosages');
			$crud->set_subject('Medicine Dosages');
			$crud->set_relation_n_n('med_name', 'medication_management_dosages', 'medications', 'med_dosage_id', 'med_id', 'med_name','priority');
			$crud->fields('med_dosage_id', 'num_times_per_day', 'amount_per_day' , 'med_name');
			$crud->columns('med_dosage_id','num_times_per_day','amount_per_day', 'med_name');
			$output = $crud->render();
			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function medication_dosages_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }

		try{
			$crud = new grocery_CRUD();
			$crud->set_table('medication_management_dosages');
			$crud->set_subject('Medicine Dosages Specifics');
			$crud->set_rules('med_id','Med Name','htmlspecialchars|required|max_length[15]');
			$crud->display_as('med_id','Med Name');
			$crud->set_relation('med_id','medications', '{med_name}');
			$crud->columns('med_id','med_dosage_id');
			$output = $crud->render();
			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}


	public function prescription_dosages_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }

		try{
			$crud = new grocery_CRUD();
			$crud->set_table('prescription_dosages');
			$crud->set_subject('Prescription Dosages Specifics');
			$crud->columns('prescription_id','med_dosage_id');
			$output = $crud->render();
			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function lungexams_management()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }
		try{
			$crud = new grocery_CRUD();
			$crud->set_table('lung_exams');
			$crud->set_subject('FEV Test');
			
			$crud->set_rules('lung_exam_id','Visit Number','htmlspecialchars|required|max_length[15]');
			$crud->display_as('lung_exam_id','Score ID');
			$crud->display_as('FEV_value','FEV');
			
			$crud->columns('lung_exam_id','FEV_value');
			$crud->unset_clone();
			$output = $crud->render();
			$output-> title = "Lung Exams";

			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function users()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }

		try{
			$crud = new grocery_CRUD();
			$crud->set_table('crud_users');
			$crud->set_subject('Users');
			$crud->required_fields('username','password');
			$crud->columns('username','password','permissions');
			$crud->change_field_type('password','password');
			$crud->unset_read()->unset_export()->unset_print();
			$crud->callback_before_insert(array($this,'encrypt_pw'));
			$crud->callback_before_update(array($this,'encrypt_pw'));
			$output = $crud->render();
			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}
	function encrypt_pw($post_array) {
		if(!empty($post_array['password'])) {
			$post_array['password'] = SHA1($_POST['password']);
			}
			return $post_array;
		}

	function set_max($post_array) {
				$post_array['FEV_value_max'] = max($_POST['FEV_value1'],$_POST['FEV_value2'],$_POST['FEV_value3']);
			    return $post_array;
	    }//function

}
