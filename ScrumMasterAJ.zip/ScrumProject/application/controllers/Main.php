<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
class Main extends CI_Controller {
 
    function __construct()
    {
        parent::__construct();
 
        /* Standard Libraries of codeigniter are required */
        $this->load->database();
        $this->load->helper('url');
 
        $this->load->library('grocery_CRUD');
 
    }
 
    public function index()
    {
        echo "<h1>Welcome to the world of Codeigniter</h1>";//Just an example to ensure that we get into the function
                die();
    }
 
    public function employees()
    {
        $crud = new grocery_CRUD();
		$crud->set_subject('Employee');
        $crud->set_table('employees');
		$crud->columns('lastName','firstName','email','jobTitle'); 
		$crud->fields('lastName','firstName','extension','email','jobTitle'); 
		$crud->display_as('lastName','Last Name');
		$crud->display_as('firstName','First Name');
		$crud->display_as('jobTitle','Job Title');
		$crud->required_fields('email','firstName','lastName'); 
		$crud->set_rules('lastName','Last Name','htmlspecialchars|required|min_length[2]|max_length[30]');
		$crud->set_rules('firstName','First Name','htmlspecialchars|required|min_length[2]|max_length[30]');
        $output = $crud->render();
		$output->title = "All Employees";
        $this->_example_output($output);        
    }

    public function customers()
    {
        $crud = new grocery_CRUD();
		$crud->set_subject('Customer');
        $crud->set_table('customers_main');
		$crud->columns('email','first_name','state','zip', 'phone', 'membership_type', 'starting_date'); 
		$crud->fields('Email','Password','First Name','State','Zip','Phone', 'Membership type', 'Starting date',);
        $crud->required_fields('email','first_name');
		$crud->set_rules('first_name','First Name','htmlspecialchars|required|min_length[2]|max_length[30]');
		$crud->change_field_type('Password', 'password');
		$crud->callback_before_insert(array($this,'encrypt_pw'));
		$crud->callback_before_update(array($this,'encrypt_pw'));
		$output = $crud->render();
		$output->title = "Our Customers";

        $this->_example_output($output);        
    }
 
    function _example_output($output = null)
 
    {
        $this->load->view('our_template.php',$output);    
    }

	function encrypt_pw($post_array) {
			    if(!empty($post_array['password'])) {
					    $post_array['password'] = SHA1($_POST['password']); 					
						SHA1($_POST['password']);
			    }//if
			    return $post_array;
	    }//function
}
 
/* End of file Main.php */
/* Location: ./application/controllers/Main.php */
