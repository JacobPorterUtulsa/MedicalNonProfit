<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ExamplesAdmins extends CI_Controller {

	public function __construct()
	{
		parent::__construct();

		$this->load->database();
		$this->load->helper('url');
		$this->load->model('login_model');
		$this->load->library('grocery_CRUD');
	}

	public function _example_output($output = null)
	{
		$this->load->view('ExamplesAdmins.php',(array)$output);
	}

	public function index()
	{
		$this->_example_output((object)array('output' => '' , 'js_files' => array() , 'css_files' => array()));
	}

	public function users()
	{
		if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }

		try{
			$crud = new grocery_CRUD();
			$crud->set_table('crud_users');
			$crud->set_subject('Users');
			$crud->required_fields('username','password','permissions');
			$crud->set_relation('permissions','crud_permissions','name');
			$crud->set_rules('username','Username','htmlspecialchars|required|min_length[2]|max_length[30]');
			$crud->set_rules('password','Password','htmlspecialchars|required|min_length[12]|max_length[200]');
			$crud->set_rules('permissions','Permissions','htmlspecialchars|required|min_length[0]|max_length[5]');
			$crud->columns('username','password','permissions');
			$crud->field_type('password','password');
			$crud->unset_read()->unset_export()->unset_print();
			$crud->callback_before_insert(array($this,'encrypt_pw'));
			$crud->callback_before_update(array($this,'encrypt_pw'));
			$crud = $this->login_model->check($crud);
			$output = $crud->render();
			$this->_example_output($output);

		}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}

	public function manage_permissions(){
				if(!$this->login_model->isLogged()){
                                 //you are not permitted to see this page, so go to the login page
                           $this->login_model->logout();
                           return; //just in case...
                      }try {
		$crud = new grocery_CRUD();
		$crud->set_table('crud_permissions');
		$crud->set_subject('Permission Management');
		$crud->required_fields('name');
        $crud->columns('name');
		$crud->display_as('name','Group Names');
		$crud->callback_field('permissions',array($this,'create_permissions_grid'));
		$crud->callback_before_insert(array($this,'elaborate_the_grid_then_update'));
		$crud->callback_before_update(array($this,'elaborate_the_grid_then_update'));
		$crud = $this->login_model->check($crud);
		$output = $crud->render();
		
		?>
		<html>
			<head>
			<title>Permissions Management</title>
			<?php 
			foreach($output->css_files as $file): ?>
				<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
			<?php endforeach; ?>
			<?php foreach($output->js_files as $file): ?>
				<script src="<?php echo $file; ?>"></script>
			<?php endforeach; ?>
			<style>
			.checkbox-grid, th, td {
			    border: 1px solid rgba(0, 0, 0, 0.49);
				text-align: center;
				padding: 5px !important;
			}
			.checkbox-grid{
				width: 100%;
			}
			</style>
			</head>
			<body>
				<?php echo $this->_example_output($output); ?>
			</body>
		</html>
		<?php
	}catch(Exception $e){
			show_error($e->getMessage().' --- '.$e->getTraceAsString());
		}
	}
	
	//This function create the GRID for all the tables with all the permissions
	function create_permissions_grid($value='', $primary_key = null){
		$perm = json_decode($value,true);
		$return = '<table class="checkbox-grid">';
		$arr = array("ID Only","Read List","Read Single","Add New","Edit","Delete");
		$tables = $this->db->list_tables();
		//ID
		$return .= '
		<tr><th>Tables</th>
		';
		foreach($arr as $a){
			$return .= '
			<th>'.$a.'</th>
			';
		}
		$return .= '</tr>';
		foreach($tables as $a){
		$return .= '<tr>
	    <td>'.$a.'</td>
	    ';

		$return .= '
		<td><input type="checkbox" name="'.$a.'[1]" value="0" '.($this->login_model->IDOnly($a,$perm)?'checked':'').'/></td>
		';
		$return .= '
	    <td><input type="checkbox" name="'.$a.'[2]" value="1" '.($this->login_model->canSeeList($a,$perm)?'checked':'').'/></td>
	    ';
		$return .= '
	    <td><input type="checkbox" name="'.$a.'[3]" value="1" '.($this->login_model->canSeeSingle($a,$perm)?'checked':'').'/></td>
	    ';
		$return .= '
	    <td><input type="checkbox" name="'.$a.'[4]" value="1" '.($this->login_model->canAdd($a,$perm)?'checked':'').'/></td>
	    ';
		$return .= '
	    <td><input type="checkbox" name="'.$a.'[5]" value="1" '.($this->login_model->canEdit($a,$perm)?'checked':'').'/></td>
	    ';
		$return .= '
	    <td><input type="checkbox" name="'.$a.'[6]" value="1" '.($this->login_model->canDelete($a,$perm)?'checked':'').'/></td>
	    ';
	    $return .= '</tr>';
	    }
		$return .= '</table>';
		global $loginConfig;
		if($loginConfig['Show Permission Management Tips'])
			$return .= '<h5>ID Only is just if you want to restrict the user to see just the record that was created by him<br/>
			How it works the GRID: Selected = YES | Deselected = NO<br/>
			Tips: NEVER let the admin without the full permissions!<br/>
			Tips 2: Give this page JUST to someone that know what he\'s doing!</h5>';

		return $return;
	}
	
	//Here the permission's array is created and converted to be saved on the database after saving/adding a new group
	function elaborate_the_grid_then_update($post_array, $primary_key=null) {
		foreach($post_array as $key=>$val){
			if($key=="name") continue;
			
			if(!isset($post_array[$key][1])) $post_array[$key][1] = 1;
			if(!isset($post_array[$key][2])) $post_array[$key][2] = 0;
			if(!isset($post_array[$key][3])) $post_array[$key][3] = 0;
			if(!isset($post_array[$key][4])) $post_array[$key][4] = 0;
			if(!isset($post_array[$key][5])) $post_array[$key][5] = 0;
			if(!isset($post_array[$key][6])) $post_array[$key][6] = 0;
			$p = $post_array[$key];
			$permissions[$key] = $p[1].$p[2].$p[3].$p[4].$p[5].$p[6];
				
		}
		$post_array = array("name"=>$post_array['name'],"permissions"=>json_encode($permissions));
		 
		return $post_array;
	}	


	function encrypt_pw($post_array) {
		$post_array['password'] = SHA1($_POST['password']);
		return $post_array;
	}//function
}
		
