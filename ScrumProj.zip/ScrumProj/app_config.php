<?php
define('APP_ROOT', $_SERVER['DOCUMENT_ROOT']);
//DEBUG echo(APP_ROOT);
define('APP_FOLDER_NAME', '/ScrumProj');
define('WEB_ROOT', 'http://'.$_SERVER['SERVER_NAME']);
//DEBUG echo (WEB_ROOT);
define ('DSN1','mysql:host=localhost;dbname=KAJERMed');
define ('USER1','root');
define ('PASSWD1','');
?>